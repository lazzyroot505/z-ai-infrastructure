# ============================================================
# Z-AI Platform - Next.js Configuration
# next.config.js
# ============================================================

/** @type {import('next').NextConfig} */
const nextConfig = {
  // ------------------------------------------------------------
  // REACT MODE
  // ------------------------------------------------------------
  reactStrictMode: true,

  // ------------------------------------------------------------
  // OUTPUT CONFIGURATION
  // ------------------------------------------------------------
  output: 'standalone',
  
  // Trailing slashes
  trailingSlash: false,

  // ------------------------------------------------------------
  // IMAGE OPTIMIZATION
  // ------------------------------------------------------------
  images: {
    // External image domains
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'api.z-ai.dev',
        pathname: '/images/**',
      },
      {
        protocol: 'https',
        hostname: 'cdn.z-ai.dev',
        pathname: '/**',
      },
    ],
    // Image formats
    formats: ['image/avif', 'image/webp'],
    // Device sizes for responsive images
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    // Image sizes
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    // Minimum cache TTL
    minimumCacheTTL: 60 * 60 * 24 * 30, // 30 days
  },

  // ------------------------------------------------------------
  // EXPERIMENTAL FEATURES
  // ------------------------------------------------------------
  experimental: {
    // Enable typed routes
    typedRoutes: true,
    // Server actions
    serverActions: {
      bodySizeLimit: '10mb',
    },
    // Optimize package imports
    optimizePackageImports: [
      '@radix-ui/react-icons',
      'lucide-react',
      'framer-motion',
    ],
  },

  // ------------------------------------------------------------
  // ENVIRONMENT VARIABLES
  // ------------------------------------------------------------
  env: {
    NEXT_PUBLIC_APP_NAME: 'Z-AI',
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'https://api.z-ai.dev',
    NEXT_PUBLIC_WS_URL: process.env.NEXT_PUBLIC_WS_URL || 'wss://api.z-ai.dev/ws',
  },

  // ------------------------------------------------------------
  // HEADERS (Security)
  // ------------------------------------------------------------
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'geolocation=(), microphone=(), camera=()',
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=31536000; includeSubDomains; preload',
          },
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
              "style-src 'self' 'unsafe-inline'",
              "img-src 'self' data: https: blob:",
              "font-src 'self' data:",
              "connect-src 'self' https://api.z-ai.dev wss://api.z-ai.dev",
              "frame-ancestors 'self'",
              "base-uri 'self'",
              "form-action 'self'",
              "object-src 'none'",
            ].join('; '),
          },
        ],
      },
    ]
  },

  // ------------------------------------------------------------
  // REDIRECTS
  // ------------------------------------------------------------
  async redirects() {
    return [
      {
        source: '/api/v1/:path*',
        destination: '/api/:path*',
        permanent: true,
      },
      {
        source: '/docs',
        destination: '/docs/introduction',
        permanent: false,
      },
    ]
  },

  // ------------------------------------------------------------
  // REWRITES (API Proxy)
  // ------------------------------------------------------------
  async rewrites() {
    return [
      {
        source: '/api/external/:path*',
        destination: `${process.env.BACKEND_URL}/api/:path*`,
      },
    ]
  },

  // ------------------------------------------------------------
  // WEBPACK CONFIGURATION
  // ------------------------------------------------------------
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    // Enable top-level await
    config.experiments = {
      ...config.experiments,
      topLevelAwait: true,
    }

    // Bundle analyzer (development only)
    if (process.env.ANALYZE === 'true') {
      const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer')
      config.plugins.push(
        new BundleAnalyzerPlugin({
          analyzerMode: 'static',
          openAnalyzer: false,
        })
      )
    }

    // Ignore specific warnings
    config.ignoreWarnings = [
      { module: /node_modules\/msw/ },
    ]

    return config
  },

  // ------------------------------------------------------------
  // LOGGING
  // ------------------------------------------------------------
  logging: {
    fetches: {
      fullUrl: true,
      hmrRefreshes: true,
    },
  },

  // ------------------------------------------------------------
  // TYPESCRIPT
  // ------------------------------------------------------------
  typescript: {
    // Enable type checking in production
    ignoreBuildErrors: false,
    // Custom tsconfig path
    tsconfigPath: './tsconfig.json',
  },

  // ------------------------------------------------------------
  // ESLINT
  // ------------------------------------------------------------
  eslint: {
    // Enable ESLint in production
    ignoreDuringBuilds: false,
    // ESLint cache
    dirs: ['src'],
  },

  // ------------------------------------------------------------
  // COMPRESSION
  // ------------------------------------------------------------
  compress: true,

  // ------------------------------------------------------------
  // POWERED BY HEADER
  // ------------------------------------------------------------
  poweredByHeader: false,

  // ------------------------------------------------------------
  // GENERATE ETAGS
  // ------------------------------------------------------------
  generateEtags: true,

  // ------------------------------------------------------------
  // ON DEMAND ENTRIES (Development)
  // ------------------------------------------------------------
  onDemandEntries: {
    maxInactiveAge: 60 * 1000, // 1 minute
    pagesBufferLength: 5,
  },
}

module.exports = nextConfig
