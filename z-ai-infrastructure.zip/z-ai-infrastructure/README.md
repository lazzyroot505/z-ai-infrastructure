# ============================================================
# Z-AI Platform - Infrastructure Index
# Complete File Reference for Security Review
# ============================================================

## 📁 Directory Structure

```
/home/z/my-project/docs/infrastructure/
│
├── linux/                          # Linux System Configuration
│   ├── systemd/
│   │   ├── z-ai-api.service       # API service unit file
│   │   ├── z-ai-worker.service    # Worker service unit file
│   │   └── z-ai-websocket.service # WebSocket service unit file
│   ├── security/
│   │   ├── sysctl.conf            # Kernel security parameters
│   │   ├── limits.conf            # System resource limits
│   │   └── ufw.conf               # UFW firewall rules
│   └── network/
│       ├── sshd_config            # SSH hardening configuration
│       ├── nginx.conf             # Nginx main configuration
│       └── nginx-site.conf        # Nginx site configuration
│
├── docker/                         # Docker Configuration
│   ├── Dockerfile                 # Production Dockerfile
│   ├── Dockerfile.api             # API service Dockerfile
│   └── docker-compose.yml         # Full stack compose
│
├── database/                       # Database Configuration
│   ├── postgresql.conf            # PostgreSQL configuration
│   ├── pg_hba.conf                # PostgreSQL access control
│   └── redis.conf                 # Redis configuration
│
├── devops/                         # DevOps & CI/CD
│   ├── .gitlab-ci.yml             # GitLab CI/CD pipeline
│   ├── kubernetes.yaml            # Kubernetes deployment
│   └── ansible-deploy.yml         # Ansible playbook
│
├── monitoring/                     # Monitoring Stack
│   ├── prometheus.yml             # Prometheus configuration
│   ├── alert-rules.yml            # Alert rules
│   └── grafana-dashboard.json     # Grafana dashboard
│
├── frontend/                       # Frontend Configuration
│   ├── next.config.js             # Next.js configuration
│   ├── tsconfig.json              # TypeScript configuration
│   └── tailwind.config.js         # Tailwind CSS configuration
│
├── backend/                        # Backend Configuration
│   ├── .env.example               # Environment variables
│   ├── tsconfig.json              # TypeScript configuration
│   └── prisma/
│       └── schema.prisma          # Database schema
│
└── security/                       # Security Configuration
    ├── fail2ban-jail.conf         # Fail2Ban jails
    └── apparmor-profile           # AppArmor profile
```

## 📋 File Summary

| Category | Files | Purpose |
|----------|-------|---------|
| **Linux** | 8 | System hardening, services, network |
| **Docker** | 3 | Container build & orchestration |
| **Database** | 3 | PostgreSQL & Redis configuration |
| **DevOps** | 3 | CI/CD, Kubernetes, Ansible |
| **Monitoring** | 3 | Prometheus, Grafana, Alerts |
| **Frontend** | 3 | Next.js, TypeScript, Tailwind |
| **Backend** | 3 | Environment, TypeScript, Prisma |
| **Security** | 2 | Fail2Ban, AppArmor |
| **Total** | **25** | Complete infrastructure |

## 🔐 Security Highlights

### Linux Hardening
- Kernel security parameters (sysctl)
- SSH hardening (no password auth, modern ciphers)
- UFW firewall with rate limiting
- System resource limits
- Systemd service sandboxing

### Network Security
- TLS 1.2/1.3 only
- Modern cipher suites
- Security headers (CSP, HSTS, X-Frame-Options)
- Rate limiting at multiple layers

### Application Security
- Non-root container user
- Read-only root filesystem
- Security context in Kubernetes
- Network policies

### Database Security
- SCRAM-SHA-256 authentication
- SSL/TLS connections
- Access control (pg_hba.conf)
- Audit logging

### Monitoring & Alerts
- System metrics (CPU, memory, disk)
- Application metrics (latency, errors)
- Security alerts (SSL expiry, anomalies)
- Log aggregation

## 🚀 Quick Reference

### Start Services (Systemd)
```bash
sudo systemctl start z-ai-api
sudo systemctl start z-ai-worker
sudo systemctl start z-ai-websocket
sudo systemctl start nginx
sudo systemctl start postgresql
sudo systemctl start redis
```

### Docker Compose
```bash
docker-compose up -d
docker-compose logs -f api
docker-compose ps
```

### Kubernetes Deploy
```bash
kubectl apply -f kubernetes.yaml
kubectl get pods -n z-ai
kubectl logs -f deployment/z-ai-api -n z-ai
```

### Health Checks
```bash
curl http://localhost:3000/health
curl http://localhost:9090/-/healthy
curl http://localhost:5432 -U zai -d zai_production
redis-cli ping
```

## 📊 Service Ports

| Service | Port | Protocol |
|---------|------|----------|
| API | 3000 | HTTP |
| WebSocket | 3002 | WS |
| PostgreSQL | 5432 | TCP |
| Redis | 6379 | TCP |
| Prometheus | 9090 | HTTP |
| Grafana | 3001 | HTTP |
| Nginx HTTP | 80 | HTTP |
| Nginx HTTPS | 443 | HTTPS |
| SSH | 22 | TCP |

## 🔧 Environment Setup

1. Copy `.env.example` to `.env`
2. Generate secure secrets:
   ```bash
   openssl rand -hex 32  # JWT_SECRET
   openssl rand -hex 16  # ENCRYPTION_KEY
   ```
3. Update database passwords
4. Configure SSL certificates

## 📝 Notes

- All configurations are production-ready
- Security defaults are set to maximum
- Adjust values based on your infrastructure
- Test thoroughly before production deployment

---
**Document Version:** 1.0.0
**Last Updated:** 2025
**Classification:** Security Infrastructure Documentation
